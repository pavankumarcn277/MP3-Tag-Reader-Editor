#include<stdio.h>
#include"types.h"
#include"view.h"
#include<string.h>

char *tags_arr[6] = {"Title","Artist","Album","Year","Content Type","Comment"};

void big_to_lil(void * size)  //Logic to convert from lil to big and vice versa
{
    char temp;
    for(int i=0;i<2;i++)
    {
        temp = *((char*)size+i);
        *((char*)size+i) = *((char*)size+3-i);
        *((char*)size+3-i) = temp;
    }
}

Status read_and_validate_mp3(char *fname)
{
    if(strstr(fname,".mp3") != NULL)
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}



Status view_and_print_data(mp3Info *info)
{
    fseek(info->fptr_mp3, 10, SEEK_SET);

    char buffer[5];
    int size;
    char data[100];

    printf("----------------------------------------------------------------------------\n");
    printf("MP3 Tag Reader and Editor for ID3v2.3\n");
    printf("----------------------------------------------------------------------------\n");

    for(int i = 0; i < 6; i++)
    {
        if(fread(buffer,1,4,info->fptr_mp3) != 4)
            return e_failure;

        buffer[4] = '\0';
        //printf("Frame ID: %s\n", buffer);

        if(fread(&size,1,4,info->fptr_mp3) != 4)
            return e_failure;

        big_to_lil(&size);
        //printf("Size: %d\n", size);

        fseek(info->fptr_mp3, 2, SEEK_CUR);

        if(size > sizeof(data))
            return e_failure;

        if(fread(data,1,size,info->fptr_mp3) != size)
            return e_failure;

        data[size] = '\0';
        //printf("Data: %s\n\n", data+1);
       
        printf("%-20s :\t\t %-70s\n",tags_arr[i],data+1);
    }
    printf("----------------------------------------------------------------------------\n");
    return e_success;
}